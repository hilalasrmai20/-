﻿// Decompiled with JetBrains decompiler
// Type: WebCamSEMO.frmCamera
// Assembly: WebCamSEMO, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 22461A1D-DE75-4A8B-929E-4C160E19E676
// Assembly location: C:\Users\hilal\Desktop\SEMO_webCam\WebCamSEMO.exe

using AForge.Controls;
using AForge.Video;
using AForge.Video.DirectShow;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using WebCamSEMO.My;

namespace WebCamSEMO
{
  [DesignerGenerated]
  public class frmCamera : Form
  {
    private static List<WeakReference> __ENCList = new List<WeakReference>();
    private IContainer components;
    [AccessedThroughProperty("PictureBox1")]
    private System.Windows.Forms.PictureBox _PictureBox1;
    [AccessedThroughProperty("VideoSourcePlayer1")]
    private VideoSourcePlayer _VideoSourcePlayer1;
    [AccessedThroughProperty("ButtonStop")]
    private Button _ButtonStop;
    [AccessedThroughProperty("ButtonStart")]
    private Button _ButtonStart;
    [AccessedThroughProperty("Label2")]
    private Label _Label2;
    [AccessedThroughProperty("Label1")]
    private Label _Label1;
    [AccessedThroughProperty("ComboBoxModes")]
    private ComboBox _ComboBoxModes;
    [AccessedThroughProperty("ComboBoxSources")]
    private ComboBox _ComboBoxSources;
    [AccessedThroughProperty("Button1")]
    private Button _Button1;
    [AccessedThroughProperty("Button2")]
    private Button _Button2;
    [AccessedThroughProperty("SaveFileDialog1")]
    private SaveFileDialog _SaveFileDialog1;
    private FilterInfoCollection videoDevices;
    private VideoCapabilities[] videoCapabilities;
    private VideoCaptureDevice videoDevice;
    private string SavedPath;
    private string GetData1;
    private string GetData2;
    public object F;
    public string R;

    [DebuggerNonUserCode]
    static frmCamera()
    {
    }

    public frmCamera()
    {
      this.FormClosing += new FormClosingEventHandler(this.frmCamera_FormClosing);
      this.Load += new EventHandler(this.frmCamera_Load);
      frmCamera.__ENCAddToList((object) this);
      this.F = (object) new Computer();
      this.R = "WebCamSEMO";
      this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    private static void __ENCAddToList(object value)
    {
      lock (frmCamera.__ENCList)
      {
        if (frmCamera.__ENCList.Count == frmCamera.__ENCList.Capacity)
        {
          int index1 = 0;
          int num = checked (frmCamera.__ENCList.Count - 1);
          int index2 = 0;
          while (index2 <= num)
          {
            if (frmCamera.__ENCList[index2].IsAlive)
            {
              if (index2 != index1)
                frmCamera.__ENCList[index1] = frmCamera.__ENCList[index2];
              checked { ++index1; }
            }
            checked { ++index2; }
          }
          frmCamera.__ENCList.RemoveRange(index1, checked (frmCamera.__ENCList.Count - index1));
          frmCamera.__ENCList.Capacity = frmCamera.__ENCList.Count;
        }
        frmCamera.__ENCList.Add(new WeakReference(RuntimeHelpers.GetObjectValue(value)));
      }
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
      try
      {
        if (!disposing || this.components == null)
          return;
        this.components.Dispose();
      }
      finally
      {
        base.Dispose(disposing);
      }
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
      this.PictureBox1 = new System.Windows.Forms.PictureBox();
      this.VideoSourcePlayer1 = new VideoSourcePlayer();
      this.ButtonStop = new Button();
      this.ButtonStart = new Button();
      this.Label2 = new Label();
      this.Label1 = new Label();
      this.ComboBoxModes = new ComboBox();
      this.ComboBoxSources = new ComboBox();
      this.Button1 = new Button();
      this.Button2 = new Button();
      this.SaveFileDialog1 = new SaveFileDialog();
      ((ISupportInitialize) this.PictureBox1).BeginInit();
      this.SuspendLayout();
      this.PictureBox1.BorderStyle = BorderStyle.FixedSingle;
      System.Windows.Forms.PictureBox pictureBox1_1 = this.PictureBox1;
      Point point1 = new Point(529, 113);
      Point point2 = point1;
      pictureBox1_1.Location = point2;
      this.PictureBox1.Name = "PictureBox1";
      System.Windows.Forms.PictureBox pictureBox1_2 = this.PictureBox1;
      Size size1 = new Size(511, 335);
      Size size2 = size1;
      pictureBox1_2.Size = size2;
      this.PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.PictureBox1.TabIndex = 15;
      this.PictureBox1.TabStop = false;
      VideoSourcePlayer videoSourcePlayer1_1 = this.VideoSourcePlayer1;
      point1 = new Point(12, 113);
      Point point3 = point1;
      videoSourcePlayer1_1.Location = point3;
      this.VideoSourcePlayer1.Name = "VideoSourcePlayer1";
      VideoSourcePlayer videoSourcePlayer1_2 = this.VideoSourcePlayer1;
      size1 = new Size(511, 335);
      Size size3 = size1;
      videoSourcePlayer1_2.Size = size3;
      this.VideoSourcePlayer1.TabIndex = 14;
      this.VideoSourcePlayer1.Text = "VideoSourcePlayer1";
      this.VideoSourcePlayer1.VideoSource = (IVideoSource) null;
      Button buttonStop1 = this.ButtonStop;
      point1 = new Point(803, 66);
      Point point4 = point1;
      buttonStop1.Location = point4;
      this.ButtonStop.Name = "ButtonStop";
      Button buttonStop2 = this.ButtonStop;
      size1 = new Size(75, 37);
      Size size4 = size1;
      buttonStop2.Size = size4;
      this.ButtonStop.TabIndex = 13;
      this.ButtonStop.Text = "Stop";
      this.ButtonStop.UseVisualStyleBackColor = true;
      Button buttonStart1 = this.ButtonStart;
      point1 = new Point(722, 66);
      Point point5 = point1;
      buttonStart1.Location = point5;
      this.ButtonStart.Name = "ButtonStart";
      Button buttonStart2 = this.ButtonStart;
      size1 = new Size(75, 37);
      Size size5 = size1;
      buttonStart2.Size = size5;
      this.ButtonStart.TabIndex = 12;
      this.ButtonStart.Text = "Start";
      this.ButtonStart.UseVisualStyleBackColor = true;
      this.Label2.AutoSize = true;
      Label label2_1 = this.Label2;
      point1 = new Point(12, 78);
      Point point6 = point1;
      label2_1.Location = point6;
      this.Label2.Name = "Label2";
      Label label2_2 = this.Label2;
      size1 = new Size(58, 13);
      Size size6 = size1;
      label2_2.Size = size6;
      this.Label2.TabIndex = 11;
      this.Label2.Text = "resolution:";
      this.Label1.AutoSize = true;
      Label label1_1 = this.Label1;
      point1 = new Point(12, 51);
      Point point7 = point1;
      label1_1.Location = point7;
      this.Label1.Name = "Label1";
      Label label1_2 = this.Label1;
      size1 = new Size(46, 13);
      Size size7 = size1;
      label1_2.Size = size7;
      this.Label1.TabIndex = 10;
      this.Label1.Text = "camera:";
      this.ComboBoxModes.FormattingEnabled = true;
      ComboBox comboBoxModes1 = this.ComboBoxModes;
      point1 = new Point(76, 75);
      Point point8 = point1;
      comboBoxModes1.Location = point8;
      this.ComboBoxModes.Name = "ComboBoxModes";
      ComboBox comboBoxModes2 = this.ComboBoxModes;
      size1 = new Size(331, 21);
      Size size8 = size1;
      comboBoxModes2.Size = size8;
      this.ComboBoxModes.TabIndex = 9;
      this.ComboBoxSources.FormattingEnabled = true;
      ComboBox comboBoxSources1 = this.ComboBoxSources;
      point1 = new Point(76, 48);
      Point point9 = point1;
      comboBoxSources1.Location = point9;
      this.ComboBoxSources.Name = "ComboBoxSources";
      ComboBox comboBoxSources2 = this.ComboBoxSources;
      size1 = new Size(331, 21);
      Size size9 = size1;
      comboBoxSources2.Size = size9;
      this.ComboBoxSources.TabIndex = 8;
      Button button1_1 = this.Button1;
      point1 = new Point(884, 66);
      Point point10 = point1;
      button1_1.Location = point10;
      this.Button1.Name = "Button1";
      Button button1_2 = this.Button1;
      size1 = new Size(75, 37);
      Size size10 = size1;
      button1_2.Size = size10;
      this.Button1.TabIndex = 16;
      this.Button1.Text = "Snapshot";
      this.Button1.UseVisualStyleBackColor = true;
      Button button2_1 = this.Button2;
      point1 = new Point(965, 66);
      Point point11 = point1;
      button2_1.Location = point11;
      this.Button2.Name = "Button2";
      Button button2_2 = this.Button2;
      size1 = new Size(75, 37);
      Size size11 = size1;
      button2_2.Size = size11;
      this.Button2.TabIndex = 17;
      this.Button2.Text = "save";
      this.Button2.UseVisualStyleBackColor = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      size1 = new Size(1052, 459);
      this.ClientSize = size1;
      this.Controls.Add((Control) this.Button2);
      this.Controls.Add((Control) this.Button1);
      this.Controls.Add((Control) this.PictureBox1);
      this.Controls.Add((Control) this.VideoSourcePlayer1);
      this.Controls.Add((Control) this.ButtonStop);
      this.Controls.Add((Control) this.ButtonStart);
      this.Controls.Add((Control) this.Label2);
      this.Controls.Add((Control) this.Label1);
      this.Controls.Add((Control) this.ComboBoxModes);
      this.Controls.Add((Control) this.ComboBoxSources);
      this.Name = nameof (frmCamera);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "برنامج التقاط الصور من الكاميرات وحفظها، برمجة الدكتور حسنين";
      this.TopMost = true;
      ((ISupportInitialize) this.PictureBox1).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    internal virtual System.Windows.Forms.PictureBox PictureBox1
    {
      [DebuggerNonUserCode] get => this._PictureBox1;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        this._PictureBox1 = value;
      }
    }

    internal virtual VideoSourcePlayer VideoSourcePlayer1
    {
      [DebuggerNonUserCode] get => this._VideoSourcePlayer1;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        this._VideoSourcePlayer1 = value;
      }
    }

    internal virtual Button ButtonStop
    {
      [DebuggerNonUserCode] get => this._ButtonStop;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.ButtonStop_Click);
        if (this._ButtonStop != null)
          this._ButtonStop.Click -= eventHandler;
        this._ButtonStop = value;
        if (this._ButtonStop == null)
          return;
        this._ButtonStop.Click += eventHandler;
      }
    }

    internal virtual Button ButtonStart
    {
      [DebuggerNonUserCode] get => this._ButtonStart;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.ButtonStart_Click);
        if (this._ButtonStart != null)
          this._ButtonStart.Click -= eventHandler;
        this._ButtonStart = value;
        if (this._ButtonStart == null)
          return;
        this._ButtonStart.Click += eventHandler;
      }
    }

    internal virtual Label Label2
    {
      [DebuggerNonUserCode] get => this._Label2;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set => this._Label2 = value;
    }

    internal virtual Label Label1
    {
      [DebuggerNonUserCode] get => this._Label1;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set => this._Label1 = value;
    }

    internal virtual ComboBox ComboBoxModes
    {
      [DebuggerNonUserCode] get => this._ComboBoxModes;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.ComboBoxModes_SelectedIndexChanged);
        if (this._ComboBoxModes != null)
          this._ComboBoxModes.SelectedIndexChanged -= eventHandler;
        this._ComboBoxModes = value;
        if (this._ComboBoxModes == null)
          return;
        this._ComboBoxModes.SelectedIndexChanged += eventHandler;
      }
    }

    internal virtual ComboBox ComboBoxSources
    {
      [DebuggerNonUserCode] get => this._ComboBoxSources;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.ComboBoxSources_SelectedIndexChanged);
        if (this._ComboBoxSources != null)
          this._ComboBoxSources.SelectedIndexChanged -= eventHandler;
        this._ComboBoxSources = value;
        if (this._ComboBoxSources == null)
          return;
        this._ComboBoxSources.SelectedIndexChanged += eventHandler;
      }
    }

    internal virtual Button Button1
    {
      [DebuggerNonUserCode] get => this._Button1;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.Button1_Click);
        if (this._Button1 != null)
          this._Button1.Click -= eventHandler;
        this._Button1 = value;
        if (this._Button1 == null)
          return;
        this._Button1.Click += eventHandler;
      }
    }

    internal virtual Button Button2
    {
      [DebuggerNonUserCode] get => this._Button2;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        EventHandler eventHandler = new EventHandler(this.Button2_Click);
        if (this._Button2 != null)
          this._Button2.Click -= eventHandler;
        this._Button2 = value;
        if (this._Button2 == null)
          return;
        this._Button2.Click += eventHandler;
      }
    }

    internal virtual SaveFileDialog SaveFileDialog1
    {
      [DebuggerNonUserCode] get => this._SaveFileDialog1;
      [DebuggerNonUserCode, MethodImpl(MethodImplOptions.Synchronized)] set
      {
        this._SaveFileDialog1 = value;
      }
    }

    public bool ValueNotExistAddNew(string value)
    {
      return MyProject.Computer.Registry.GetValue("HKEY_CURRENT_USER\\Software\\" + this.R, value, (object) null) != null;
    }

    public void DLV(string n)
    {
      try
      {
        object Instance = NewLateBinding.LateGet(NewLateBinding.LateGet(NewLateBinding.LateGet(this.F, (Type) null, "Registry", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CurrentUser", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CreateSubKey", new object[1]
        {
          (object) ("Software\\" + this.R)
        }, (string[]) null, (Type[]) null, (bool[]) null);
        object[] objArray = new object[1]{ (object) n };
        object[] Arguments = objArray;
        bool[] flagArray = new bool[1]{ true };
        bool[] CopyBack = flagArray;
        NewLateBinding.LateCall(Instance, (Type) null, "DeleteValue", Arguments, (string[]) null, (Type[]) null, CopyBack, true);
        if (!flagArray[0])
          return;
        n = (string) Conversions.ChangeType(RuntimeHelpers.GetObjectValue(objArray[0]), typeof (string));
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        ProjectData.ClearProjectError();
      }
    }

    public string GTV(string n)
    {
      string str;
      try
      {
        object Instance = NewLateBinding.LateGet(NewLateBinding.LateGet(NewLateBinding.LateGet(this.F, (Type) null, "Registry", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CurrentUser", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CreateSubKey", new object[1]
        {
          (object) ("Software\\" + this.R)
        }, (string[]) null, (Type[]) null, (bool[]) null);
        object[] objArray = new object[2]
        {
          (object) n,
          (object) ""
        };
        object[] Arguments = objArray;
        bool[] flagArray = new bool[2]{ true, false };
        bool[] CopyBack = flagArray;
        object obj = NewLateBinding.LateGet(Instance, (Type) null, "GetValue", Arguments, (string[]) null, (Type[]) null, CopyBack);
        if (flagArray[0])
          n = (string) Conversions.ChangeType(RuntimeHelpers.GetObjectValue(objArray[0]), typeof (string));
        str = Conversions.ToString(obj);
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        str = "";
        ProjectData.ClearProjectError();
      }
      return str;
    }

    public object STV(string n, string t)
    {
      object obj;
      try
      {
        object Instance = NewLateBinding.LateGet(NewLateBinding.LateGet(NewLateBinding.LateGet(this.F, (Type) null, "Registry", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CurrentUser", new object[0], (string[]) null, (Type[]) null, (bool[]) null), (Type) null, "CreateSubKey", new object[1]
        {
          (object) ("Software\\" + this.R)
        }, (string[]) null, (Type[]) null, (bool[]) null);
        object[] objArray = new object[2]
        {
          (object) n,
          (object) t
        };
        object[] Arguments = objArray;
        bool[] flagArray = new bool[2]{ true, true };
        bool[] CopyBack = flagArray;
        NewLateBinding.LateCall(Instance, (Type) null, "SetValue", Arguments, (string[]) null, (Type[]) null, CopyBack, true);
        if (flagArray[0])
          n = (string) Conversions.ChangeType(RuntimeHelpers.GetObjectValue(objArray[0]), typeof (string));
        if (flagArray[1])
          t = (string) Conversions.ChangeType(RuntimeHelpers.GetObjectValue(objArray[1]), typeof (string));
        obj = (object) true;
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        obj = (object) false;
        ProjectData.ClearProjectError();
      }
      return obj;
    }

    private void EnumerateVideoDevices()
    {
      this.GetData1 = this.GTV("camera");
      this.GetData2 = this.GTV("resolution");
      this.videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
      if (this.videoDevices.Count != 0)
      {
        try
        {
          foreach (FilterInfo videoDevice in (CollectionBase) this.videoDevices)
            this.ComboBoxSources.Items.Add((object) videoDevice.Name);
        }
        finally
        {
          IEnumerator enumerator;
          if (enumerator is IDisposable)
            (enumerator as IDisposable).Dispose();
        }
      }
      else
        this.ComboBoxSources.Items.Add((object) "No DirectShow devices found");
      this.ComboBoxSources.SelectedIndex = Conversions.ToInteger(this.GetData1);
    }

    private void EnumerateVideoModes(VideoCaptureDevice device)
    {
      this.Cursor = Cursors.WaitCursor;
      this.ComboBoxModes.Items.Clear();
      try
      {
        this.videoCapabilities = this.videoDevice.VideoCapabilities;
        VideoCapabilities[] videoCapabilities1 = this.videoCapabilities;
        int index = 0;
        while (index < videoCapabilities1.Length)
        {
          VideoCapabilities videoCapabilities2 = videoCapabilities1[index];
          if (!this.ComboBoxModes.Items.Contains((object) videoCapabilities2.FrameSize))
            this.ComboBoxModes.Items.Add((object) videoCapabilities2.FrameSize);
          checked { ++index; }
        }
        if (this.videoCapabilities.Length == 0)
          this.ComboBoxModes.Items.Add((object) "Not supported");
        this.ComboBoxModes.SelectedIndex = Conversions.ToInteger(this.GetData2);
      }
      finally
      {
        this.Cursor = Cursors.Default;
      }
    }

    [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
    private void frmCamera_FormClosing(object sender, FormClosingEventArgs e)
    {
      ProjectData.EndApp();
    }

    private void frmCamera_Load(object sender, EventArgs e)
    {
      if (!this.ValueNotExistAddNew("resolution"))
        this.STV("resolution", "0");
      if (!this.ValueNotExistAddNew("camera"))
        this.STV("camera", "0");
      this.EnumerateVideoDevices();
      try
      {
        foreach (string commandLineArg in MyProject.Application.CommandLineArgs)
          this.SavedPath = commandLineArg;
      }
      finally
      {
        IEnumerator<string> enumerator;
        enumerator?.Dispose();
      }
      this.ComboBoxSources.SelectedIndex = Conversions.ToInteger(this.GTV("camera"));
      this.ComboBoxModes.SelectedIndex = Conversions.ToInteger(this.GTV("resolution"));
      this.CameraStart();
    }

    private void ComboBoxSources_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.videoDevices.Count != 0)
      {
        this.videoDevice = new VideoCaptureDevice(this.videoDevices[this.ComboBoxSources.SelectedIndex].MonikerString);
        this.EnumerateVideoModes(this.videoDevice);
      }
      this.STV("camera", Conversions.ToString(this.ComboBoxSources.SelectedIndex));
    }

    private void ButtonStart_Click(object sender, EventArgs e) => this.CameraStart();

    private void ButtonStop_Click(object sender, EventArgs e) => this.CameraStop();

    private void CameraStart()
    {
      if (this.videoDevice == null)
        return;
      if (this.videoCapabilities != null && this.videoCapabilities.Length != 0)
        this.videoDevice.DesiredFrameSize = (Size) this.ComboBoxModes.SelectedItem;
      this.VideoSourcePlayer1.VideoSource = (IVideoSource) this.videoDevice;
      this.VideoSourcePlayer1.Start();
    }

    private void CameraStop()
    {
      if (this.VideoSourcePlayer1.VideoSource == null)
        return;
      this.VideoSourcePlayer1.SignalToStop();
      this.VideoSourcePlayer1.WaitForStop();
      this.VideoSourcePlayer1.VideoSource = (IVideoSource) null;
    }

    private void Button1_Click(object sender, EventArgs e)
    {
      this.PictureBox1.Image = (Image) this.VideoSourcePlayer1.GetCurrentVideoFrame();
    }

    private void Button2_Click(object sender, EventArgs e)
    {
      try
      {
        this.PictureBox1.Image.Save(this.SavedPath);
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        int num = (int) MessageBox.Show(ex.Message);
        ProjectData.ClearProjectError();
      }
    }

    private void ComboBoxModes_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.STV("resolution", Conversions.ToString(this.ComboBoxModes.SelectedIndex));
    }
  }
}
