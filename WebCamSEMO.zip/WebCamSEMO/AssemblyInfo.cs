﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("WebCamSEMO")]
[assembly: AssemblyTitle("WebCamSEMO")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("e9d50ecb-0d43-4755-82da-1b03c6bb990b")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
