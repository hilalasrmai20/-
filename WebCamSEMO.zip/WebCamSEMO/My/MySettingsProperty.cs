﻿// Decompiled with JetBrains decompiler
// Type: WebCamSEMO.My.MySettingsProperty
// Assembly: WebCamSEMO, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 22461A1D-DE75-4A8B-929E-4C160E19E676
// Assembly location: C:\Users\hilal\Desktop\SEMO_webCam\WebCamSEMO.exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace WebCamSEMO.My
{
  [CompilerGenerated]
  [HideModuleName]
  [DebuggerNonUserCode]
  [StandardModule]
  internal sealed class MySettingsProperty
  {
    [HelpKeyword("My.Settings")]
    internal static MySettings Settings
    {
      get
      {
        MySettings settings = MySettings.Default;
        return settings;
      }
    }
  }
}
