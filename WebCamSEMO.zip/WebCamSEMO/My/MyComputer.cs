﻿// Decompiled with JetBrains decompiler
// Type: WebCamSEMO.My.MyComputer
// Assembly: WebCamSEMO, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 22461A1D-DE75-4A8B-929E-4C160E19E676
// Assembly location: C:\Users\hilal\Desktop\SEMO_webCam\WebCamSEMO.exe

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;


namespace WebCamSEMO.My
{
  [EditorBrowsable(EditorBrowsableState.Never)]
  [GeneratedCode("MyTemplate", "10.0.0.0")]
  internal class MyComputer : Computer
  {
    [DebuggerHidden]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public MyComputer()
    {
    }
  }
}
