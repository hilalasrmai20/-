﻿// Decompiled with JetBrains decompiler
// Type: WebCamSEMO.My.Resources.Resources
// Assembly: WebCamSEMO, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 22461A1D-DE75-4A8B-929E-4C160E19E676
// Assembly location: C:\Users\hilal\Desktop\SEMO_webCam\WebCamSEMO.exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
namespace WebCamSEMO.My.Resources
{
  [DebuggerNonUserCode]
  [HideModuleName]
  [CompilerGenerated]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [StandardModule]
  internal sealed class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) WebCamSEMO.My.Resources.Resources.resourceMan, (object) null))
          WebCamSEMO.My.Resources.Resources.resourceMan = new ResourceManager("WebCamSEMO.Resources", typeof (WebCamSEMO.My.Resources.Resources).Assembly);
        return WebCamSEMO.My.Resources.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => WebCamSEMO.My.Resources.Resources.resourceCulture;
      set => WebCamSEMO.My.Resources.Resources.resourceCulture = value;
    }
  }
}
